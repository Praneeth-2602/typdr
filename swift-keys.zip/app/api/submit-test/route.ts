import { NextRequest, NextResponse } from "next/server";
import type { SessionResult } from "@/lib/stores/analytics";
import { submitTest } from "@/lib/server/db";
import { requireSessionIdentity } from "@/lib/server/session";

export const runtime = "nodejs";

interface SubmitTestRequest {
  session?: SessionResult;
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as SubmitTestRequest;
    if (!body.session) {
      return NextResponse.json({ error: "session is required." }, { status: 400 });
    }

    const identity = await requireSessionIdentity();
    const result = await submitTest({
      userId: identity.userId,
      username: identity.username,
      session: body.session,
    });

    return NextResponse.json(result);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to submit test.";
    const status = /Unauthorized/.test(message) ? 401 : /required|Missing MONGODB_URI/.test(message) ? 400 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
