"use client";

import { useState } from "react";
import { motion, useMotionTemplate, useMotionValue, useSpring } from "framer-motion";
import {
  RotateCcw,
  Shuffle,
  Zap,
  Flame,
  TrendingUp,
  TrendingDown,
  Sparkles,
  Target,
  Gauge,
  TimerReset,
  TriangleAlert,
  Activity,
  Crosshair,
  WandSparkles,
} from "lucide-react";
import clsx from "clsx";
import type { SessionResult, StreakInfo, WeakKeyStat } from "@/lib/stores/analytics";
import { useAnalyticsStore } from "@/lib/stores/analytics";
import { getSessionWeakKeys } from "@/lib/utils/feedback";

interface ResultCardProps {
  result: SessionResult;
  onRestart: () => void;
  onNewSession?: () => void;
  newSessionLabel?: string;
  onDrill?: () => void;
  syncedWeakKeys?: WeakKeyStat[];
  syncedFeedback?: string[];
  syncedStreak?: StreakInfo | null;
}

function StatBox({
  label,
  value,
  unit,
  accent,
  sub,
}: {
  label: string;
  value: number | string;
  unit?: string;
  accent?: boolean;
  sub?: string;
}) {
  return (
    <div className="flex flex-col items-center gap-1 p-5 bg-surface-secondary border border-surface-border rounded-xl">
      <div className={clsx("font-mono font-bold text-3xl", accent ? "text-brand" : "text-slate-100")}>
        {value}
        {unit && <span className="text-lg ml-0.5 text-slate-500">{unit}</span>}
      </div>
      <div className="text-xs text-slate-500 uppercase font-mono tracking-wide">{label}</div>
      {sub && <div className="text-[10px] text-slate-600 mt-0.5">{sub}</div>}
    </div>
  );
}

function perfLabel(wpm: number) {
  if (wpm >= 100) return "Blazing fast 🔥";
  if (wpm >= 80) return "Excellent speed 💪";
  if (wpm >= 60) return "Solid performance";
  if (wpm >= 40) return "Getting there";
  return "Keep practicing";
}

function insightTone(accuracy: number, consistency: number, rawDelta: number) {
  if (accuracy >= 97 && consistency >= 88) return "Clean, controlled run.";
  if (rawDelta > 8) return "Your hands were fast, but errors held the score back.";
  if (consistency < 75) return "Speed was there in bursts. Rhythm is the next unlock.";
  if (accuracy >= 92) return "Strong control. A little more push will convert into speed.";
  return "This run exposed useful weak spots to train next.";
}

function buildInsights(result: SessionResult, recentAverage: number, previousBest: number) {
  const rawDelta = result.rawWpm - result.wpm;
  const versusAverage = recentAverage > 0 ? result.wpm - recentAverage : 0;
  const pbMargin = previousBest > 0 ? result.wpm - previousBest : result.wpm;

  const cards = [
    {
      icon: Gauge,
      title: "Speed read",
      body:
        versusAverage === 0
          ? "This run landed right on your recent average."
          : `${versusAverage > 0 ? "+" : ""}${versusAverage} WPM versus your recent pace.`,
      tone: versusAverage >= 0 ? "good" : "neutral",
    },
    {
      icon: Target,
      title: "Accuracy read",
      body:
        rawDelta > 8
          ? `${rawDelta} WPM leaked through errors. Tightening accuracy will pay off fast.`
          : `Accuracy stayed controlled at ${result.accuracy}%, which kept the score honest.`,
      tone: rawDelta > 8 ? "warn" : "good",
    },
    {
      icon: TimerReset,
      title: "Rhythm read",
      body:
        result.consistency >= 85
          ? `Consistency hit ${result.consistency}%. You held your cadence well.`
          : `Consistency was ${result.consistency}%. Smoother pacing could lift your next score.`,
      tone: result.consistency >= 85 ? "good" : "neutral",
    },
  ];

  if (pbMargin > 0 && previousBest > 0) {
    cards[0] = {
      icon: Sparkles,
      title: "New ceiling",
      body: `You pushed ${pbMargin} WPM past your previous best.`,
      tone: "good",
    };
  }

  return cards;
}

function scoreBars(result: SessionResult) {
  return [
    { label: "speed", value: Math.min(result.wpm, 100) },
    { label: "accuracy", value: result.accuracy },
    { label: "control", value: result.consistency },
    {
      label: "clean run",
      value: Math.max(0, Math.min(100, 100 - Math.max(0, result.rawWpm - result.wpm) * 4)),
    },
  ];
}

function buildFocusMetrics(result: SessionResult, previousBest: number, recentAverage: number) {
  return [
    {
      id: "speed",
      label: "Speed edge",
      value: `${result.wpm} WPM`,
      detail:
        previousBest > 0 && result.wpm > previousBest
          ? `You beat your old ceiling by ${result.wpm - previousBest} WPM.`
          : recentAverage > 0
            ? `${result.wpm - recentAverage >= 0 ? "+" : ""}${result.wpm - recentAverage} WPM against your recent average.`
            : "This is the pace to anchor future sessions against.",
      icon: Activity,
    },
    {
      id: "accuracy",
      label: "Precision",
      value: `${result.accuracy}%`,
      detail:
        result.rawWpm - result.wpm > 8
          ? `Your speed was there, but ${result.rawWpm - result.wpm} WPM got shaved off by errors.`
          : "Accuracy stayed stable enough to protect the score.",
      icon: Crosshair,
    },
    {
      id: "control",
      label: "Control",
      value: `${result.consistency}%`,
      detail:
        result.consistency >= 85
          ? "Cadence stayed smooth through most of the run."
          : "Pacing swung around a bit. Control is the easiest next gain.",
      icon: WandSparkles,
    },
  ];
}

function buildSessionConsistencySeries(result: SessionResult, points = 24, windowSize = 12) {
  const log = result.keystrokeLog ?? [];
  if (log.length < 2) return [result.wpm];

  const safeWindow = Math.min(windowSize, Math.max(2, log.length));
  const maxStart = Math.max(0, log.length - safeWindow);
  const step = Math.max(1, Math.ceil((maxStart + 1) / points));
  const values: number[] = [];

  for (let start = 0; start <= maxStart; start += step) {
    const end = Math.min(log.length - 1, start + safeWindow - 1);
    const chunk = log.slice(start, end + 1);
    const correctChars = chunk.filter((event) => event.correct).length;
    const elapsedMs = Math.max(1, chunk[chunk.length - 1].timestamp - chunk[0].timestamp);
    const chunkWpm = Math.min(999, Math.round((correctChars / 5) / (elapsedMs / 60000)));
    values.push(Number.isFinite(chunkWpm) ? chunkWpm : 0);
  }

  if (!values.length) return [result.wpm];
  return values;
}

function buildSparklinePath(values: number[], width: number, height: number) {
  if (values.length <= 1) {
    const y = height / 2;
    return `M 0 ${y} L ${width} ${y}`;
  }

  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = Math.max(1, max - min);

  return values
    .map((value, index) => {
      const x = (index / (values.length - 1)) * width;
      const y = height - ((value - min) / range) * height;
      return `${index === 0 ? "M" : "L"} ${x.toFixed(2)} ${y.toFixed(2)}`;
    })
    .join(" ");
}

export function ResultCard({
  result,
  onRestart,
  onNewSession,
  newSessionLabel = "New practice session",
  onDrill,
  syncedWeakKeys,
  syncedFeedback,
  syncedStreak,
}: ResultCardProps) {
  const trend = useAnalyticsStore((s) => s.getAccuracyTrend());
  const sessions = useAnalyticsStore((s) => s.sessions);
  const streak = useAnalyticsStore((s) => s.getStreakInfo());
  const previousSessions = sessions.filter((session) => session.id !== result.id);
  const previousBest = previousSessions.length ? Math.max(...previousSessions.map((session) => session.wpm)) : 0;
  const recentAverage = previousSessions.length
    ? Math.round(
      previousSessions
        .slice(0, 10)
        .reduce((total, session) => total + session.wpm, 0) / Math.min(previousSessions.length, 10)
    )
    : 0;
  const isNewPb = result.wpm > previousBest || previousSessions.length === 0;

  const rawDelta = result.rawWpm - result.wpm;
  const accuracyHurt = rawDelta > 8;
  const insights = buildInsights(result, recentAverage, previousBest);
  const breakdown = scoreBars(result);
  const bentoTransition = { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const };
  const focusMetrics = buildFocusMetrics(result, previousBest, recentAverage);
  const sessionWeakKeys = syncedWeakKeys ?? getSessionWeakKeys(result, 5);
  const feedback = syncedFeedback ?? result.feedback ?? [];
  const displayStreak = syncedStreak ?? streak;
  const [activeMetric, setActiveMetric] = useState(focusMetrics[0].id);
  const spotlightX = useMotionValue(50);
  const spotlightY = useMotionValue(50);
  const smoothX = useSpring(spotlightX, { stiffness: 160, damping: 24, mass: 0.5 });
  const smoothY = useSpring(spotlightY, { stiffness: 160, damping: 24, mass: 0.5 });
  const spotlight = useMotionTemplate`radial-gradient(420px circle at ${smoothX}% ${smoothY}%, rgba(232,245,92,0.16), transparent 55%)`;
  const activeFocus = focusMetrics.find((metric) => metric.id === activeMetric) ?? focusMetrics[0];
  const consistencySeries = buildSessionConsistencySeries(result, 24, 12);
  const consistencyPath = buildSparklinePath(consistencySeries, 320, 84);
  const consistencyDelta = consistencySeries.length > 1
    ? consistencySeries[consistencySeries.length - 1] - consistencySeries[0]
    : 0;
  const consistencyMin = Math.min(...consistencySeries);
  const consistencyMax = Math.max(...consistencySeries);
  const consistencyRange = Math.max(1, consistencyMax - consistencyMin);
  const consistencyLastY = 84 - ((consistencySeries[consistencySeries.length - 1] - consistencyMin) / consistencyRange) * 84;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative w-full max-w-4xl mx-auto"
    >
      {isNewPb && (
        <div className="pointer-events-none absolute inset-x-0 top-0 -z-10 flex justify-center overflow-hidden">
          <div className="relative h-36 w-full max-w-3xl">
            {Array.from({ length: 18 }).map((_, index) => {
              const left = 5 + index * 5;
              const delay = index * 0.04;
              const colors = [
                "bg-brand",
                "bg-correct",
                "bg-amber-400",
                "bg-sky-400",
              ];
              return (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 0, x: 0, scale: 0.4 }}
                  animate={{
                    opacity: [0, 1, 1, 0],
                    y: [0, 24 + (index % 3) * 14, 90 + (index % 4) * 12],
                    x: [0, (index % 2 === 0 ? -1 : 1) * (20 + (index % 5) * 10)],
                    rotate: [0, 120, 240],
                    scale: [0.4, 1, 0.9],
                  }}
                  transition={{ duration: 1.5, delay, ease: "easeOut" }}
                  className={clsx(
                    "absolute top-5 h-2.5 w-2.5 rounded-sm",
                    colors[index % colors.length]
                  )}
                  style={{ left: `${left}%` }}
                />
              );
            })}
          </div>
        </div>
      )}

      <div className="mb-4 font-mono text-xs uppercase tracking-[0.28em] text-slate-500">
        Test complete
      </div>

      <div
        className="relative overflow-hidden rounded-[32px]"
        onMouseMove={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          const x = ((event.clientX - rect.left) / rect.width) * 100;
          const y = ((event.clientY - rect.top) / rect.height) * 100;
          spotlightX.set(x);
          spotlightY.set(y);
        }}
      >
        <div className="pointer-events-none absolute inset-0 z-[5]">
          <motion.div
            aria-hidden="true"
            className="absolute h-44 w-44 rounded-full bg-brand/20 blur-3xl"
            animate={{
              x: ["5%", "40%", "75%", "55%", "20%", "5%"],
              y: ["10%", "20%", "50%", "70%", "60%", "10%"],
              scale: [1, 1.15, 0.92, 1.08, 0.96, 1],
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
          />
          <motion.div
            aria-hidden="true"
            className="absolute h-28 w-28 rounded-full bg-sky-400/12 blur-3xl"
            animate={{
              x: ["72%", "86%", "58%", "30%", "72%"],
              y: ["16%", "50%", "80%", "44%", "16%"],
              scale: [0.86, 1.14, 0.92, 1.06, 0.86],
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
          />
        </div>
        <div className="relative z-10 grid grid-cols-1 gap-4 md:grid-cols-12">
          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={bentoTransition}
            className="relative z-10 overflow-hidden rounded-[28px] border border-brand/20 bg-[radial-gradient(circle_at_top_left,rgba(232,245,92,0.16),transparent_32%),linear-gradient(180deg,rgba(27,31,34,0.82),rgba(17,18,24,0.88))] p-6 backdrop-blur-xl md:col-span-6 md:row-span-2"
          >
            <motion.div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0"
              style={{ background: spotlight }}
            />
            <motion.div
              aria-hidden="true"
              className="pointer-events-none absolute -right-8 top-6 h-40 w-40 rounded-full border border-brand/15"
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            />
            <motion.div
              aria-hidden="true"
              className="pointer-events-none absolute -right-2 top-12 h-28 w-28 rounded-full border border-brand/10"
              animate={{ rotate: -360 }}
              transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
            />
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <div className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-500">Swiftkeys score</div>
                <div className="mt-4 flex items-center gap-4">
                  <div className="relative grid h-28 w-28 place-items-center rounded-full border border-brand/20 bg-surface/20">
                    <motion.div
                      className="absolute inset-2 rounded-full border border-brand/15"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    />
                    <motion.div
                      className="absolute inset-[14px] rounded-full border border-brand/10"
                      animate={{ rotate: -360 }}
                      transition={{ duration: 7, repeat: Infinity, ease: "linear" }}
                    />
                    <div className="relative text-center">
                      <div className="font-mono text-4xl font-bold leading-none text-brand">{result.wpm}</div>
                      <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.22em] text-slate-500">wpm</div>
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <h2 className="font-mono text-3xl font-bold leading-none text-slate-100">{perfLabel(result.wpm)}</h2>
                    <div className="mt-3 grid grid-cols-3 gap-2">
                      {focusMetrics.map((metric) => {
                        const Icon = metric.icon;
                        return (
                          <button
                            key={metric.id}
                            onClick={() => setActiveMetric(metric.id)}
                            className={clsx(
                              "flex min-h-[3.5rem] w-full items-center justify-center gap-2 rounded-2xl border px-2 py-2 text-center font-mono text-[10px] uppercase tracking-[0.14em] transition-all",
                              activeMetric === metric.id
                                ? "border-brand/30 bg-brand/10 text-brand"
                                : "border-surface-border bg-surface/30 text-slate-500 hover:text-slate-300"
                            )}
                          >
                            <Icon size={12} />
                            <span className="leading-tight">{metric.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-mono text-[11px] uppercase tracking-[0.24em] text-slate-600">raw</div>
                <div className="mt-2 font-mono text-2xl font-bold text-slate-200">{result.rawWpm}</div>
              </div>
            </div>
            {isNewPb && (
              <motion.div
                initial={{ scale: 0.94, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="mb-5 inline-flex items-center gap-2 rounded-full border border-brand/30 bg-brand/10 px-4 py-2 font-mono text-xs text-brand shadow-[0_0_40px_rgba(232,245,92,0.12)]"
              >
                <Sparkles size={14} />
                New personal best
                <span className="text-slate-300">+{Math.max(1, result.wpm - previousBest)} WPM</span>
              </motion.div>
            )}
            <div className="max-w-md">
              <p className="mt-3 text-sm leading-6 text-slate-400">{insightTone(result.accuracy, result.consistency, rawDelta)}</p>
              <p className="mt-4 text-sm leading-6 text-slate-500">
                This isn’t just a speed dump. The goal here is to surface control, rhythm, and error cost, which typical typing sites tend to flatten away.
              </p>
              <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-amber-900/30 bg-amber-950/20 px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.18em] text-amber-300">
                <Flame size={12} />
                {displayStreak.currentStreak}-day streak
                <span className="text-slate-500 normal-case tracking-normal">
                  best {displayStreak.longestStreak}
                </span>
              </div>
            </div>
            <motion.div
              key={activeFocus.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, ease: [0.22, 1, 0.36, 1] }}
              className="mt-6 rounded-2xl border border-surface-border bg-surface/30 p-4"
            >
              <div className="mb-2 flex items-center justify-between gap-3">
                <div className="font-mono text-xs uppercase tracking-[0.22em] text-slate-500">{activeFocus.label}</div>
                <div className="font-mono text-sm font-bold text-brand">{activeFocus.value}</div>
              </div>
              <p className="text-sm leading-6 text-slate-300">{activeFocus.detail}</p>
            </motion.div>
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.04 }}
            className="relative z-10 rounded-[24px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-3"
          >
            <StatBox label="Accuracy" value={result.accuracy} unit="%" />
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.08 }}
            className="relative z-10 rounded-[24px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-3"
          >
            <StatBox label="Consistency" value={result.consistency} unit="%" />
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.12 }}
            className="relative z-10 rounded-[24px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-3"
          >
            <StatBox label="Duration" value={Math.round(result.duration)} unit="s" />
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.16 }}
            className="relative z-10 rounded-[24px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-3"
          >
            <StatBox label="Errors" value={result.incorrectChars} />
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.2 }}
            className="relative z-10 rounded-[28px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-7"
          >
            <div className="mb-4 font-mono text-xs uppercase tracking-[0.24em] text-slate-500">
              What mattered in this run
            </div>
            <div className="grid gap-3 md:grid-cols-3">
              {insights.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.title}
                    initial={{ opacity: 0, y: 14 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.24 + index * 0.05, ease: [0.22, 1, 0.36, 1] }}
                    whileHover={{ y: -4, scale: 1.01 }}
                    className={clsx(
                      "rounded-2xl border p-4 shadow-[0_12px_30px_rgba(0,0,0,0.14)]",
                      item.tone === "good" && "border-brand/20 bg-brand/5",
                      item.tone === "warn" && "border-amber-900/40 bg-amber-950/20",
                      item.tone === "neutral" && "border-surface-border bg-surface-tertiary/60"
                    )}
                  >
                    <div className="mb-2 flex items-center gap-2 font-mono text-xs uppercase tracking-wide text-slate-400">
                      <Icon size={13} />
                      {item.title}
                    </div>
                    <div className="text-sm leading-6 text-slate-200">{item.body}</div>
                  </motion.div>
                );
              })}
            </div>
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.24 }}
            className="relative z-10 rounded-[28px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-5"
          >
            <div className="mb-4 font-mono text-xs uppercase tracking-[0.24em] text-slate-500">
              Session breakdown
            </div>
            <div className="space-y-3">
              {breakdown.map((item, index) => (
                <motion.div
                  key={item.label}
                  whileHover={{ scale: 1.015, x: 2 }}
                  transition={{ duration: 0.18 }}
                >
                  <div className="mb-1 flex items-center justify-between font-mono text-xs uppercase tracking-wide text-slate-500">
                    <span>{item.label}</span>
                    <span className="text-slate-300">{item.value}%</span>
                  </div>
                  <div className="h-2 rounded-full bg-surface-tertiary">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${item.value}%` }}
                      transition={{ duration: 0.65, delay: 0.28 + index * 0.06, ease: [0.22, 1, 0.36, 1] }}
                      className="h-2 rounded-full bg-brand"
                    />
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <div className="rounded-xl border border-surface-border bg-surface-tertiary/60 p-4">
                <div className="font-mono text-[11px] uppercase tracking-wide text-slate-500">correct chars</div>
                <div className="mt-2 text-2xl font-mono font-bold text-correct">{result.correctChars}</div>
              </div>
              <div className="rounded-xl border border-surface-border bg-surface-tertiary/60 p-4">
                <div className="font-mono text-[11px] uppercase tracking-wide text-slate-500">typed</div>
                <div className="mt-2 text-2xl font-mono font-bold text-slate-100">{result.totalChars}</div>
              </div>
            </div>
          </motion.section>

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.26 }}
            className="relative z-10 rounded-[28px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-4"
          >
            <div className="mb-2 flex items-center justify-between gap-3">
              <div className="font-mono text-xs uppercase tracking-[0.24em] text-slate-500">Session consistency</div>
              <div className="font-mono text-sm font-bold text-brand">{result.consistency}%</div>
            </div>

            <div className="rounded-2xl border border-surface-border bg-surface/30 p-3">
              <svg viewBox="0 0 320 84" className="h-24 w-full">
                <defs>
                  <linearGradient id="consistencyLine" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0%" stopColor="rgba(148,163,184,0.55)" />
                    <stop offset="100%" stopColor="rgba(232,245,92,0.95)" />
                  </linearGradient>
                </defs>
                <path d={consistencyPath} fill="none" stroke="url(#consistencyLine)" strokeWidth="3" strokeLinecap="round" />
                <circle
                  cx={320}
                  cy={consistencyLastY}
                  r="4"
                  fill="rgba(232,245,92,0.95)"
                />
              </svg>
            </div>

            <div className="mt-3 flex items-center justify-between font-mono text-[11px] uppercase tracking-wide text-slate-500">
              <span>{consistencySeries.length} segments</span>
              <span className={clsx(consistencyDelta >= 0 ? "text-correct" : "text-incorrect")}>
                {consistencyDelta >= 0 ? "+" : ""}{consistencyDelta} wpm
              </span>
            </div>
          </motion.section>

          {Math.abs(trend) >= 3 && (
            <motion.section
              layout
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...bentoTransition, delay: 0.28 }}
              className={clsx(
                "relative z-10",
                "rounded-[28px] border p-5 md:col-span-4",
                trend > 0
                  ? "bg-green-950/30 border-green-900/40 text-correct"
                  : "bg-red-950/30 border-red-900/40 text-incorrect"
              )}
            >
              <div className="mb-3 font-mono text-xs uppercase tracking-[0.24em] text-current/80">Trend</div>
              <div className="flex items-center gap-3 font-mono text-sm">
                {trend > 0 ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
                <span>{trend > 0 ? "+" : ""}{trend} WPM vs your last 10 sessions</span>
              </div>
            </motion.section>
          )}

          {accuracyHurt && (
            <motion.section
              layout
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...bentoTransition, delay: 0.32 }}
              className="relative z-10 rounded-[28px] border border-amber-900/40 bg-amber-950/20 p-5 text-amber-400 md:col-span-4"
            >
              <div className="mb-3 flex items-center gap-2 font-mono text-xs uppercase tracking-[0.24em]">
                <TriangleAlert size={14} />
                Accuracy cost
              </div>
              <p className="text-sm leading-6">
                Errors cost you <strong>{rawDelta} WPM</strong>. Your raw pace reached {result.rawWpm}, but control pulled the final score down to {result.wpm}.
              </p>
            </motion.section>
          )}

          {feedback.length > 0 && (
            <motion.section
              layout
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...bentoTransition, delay: 0.34 }}
              className="relative z-10 rounded-[28px] border border-sky-900/40 bg-sky-950/20 p-5 md:col-span-4"
            >
              <div className="mb-4 font-mono text-xs uppercase tracking-[0.24em] text-slate-400">
                Coach feedback
              </div>
              <div className="space-y-3">
                {feedback.map((line) => (
                  <p key={line} className="text-sm leading-6 text-slate-300">
                    {line}
                  </p>
                ))}
              </div>
            </motion.section>
          )}

          {sessionWeakKeys.length > 0 && (
            <motion.section
              layout
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...bentoTransition, delay: 0.36 }}
              className="relative z-10 rounded-[28px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-4"
            >
              <div className="mb-4 font-mono text-xs uppercase tracking-[0.24em] text-slate-500">
                Weak keys this session
              </div>
              <div className="flex flex-wrap gap-2">
                {sessionWeakKeys.map((item) => (
                  <motion.div
                    key={item.key}
                    layout
                    whileHover={{ y: -2 }}
                    className={clsx(
                      "flex items-center gap-2 rounded-lg border px-3 py-1.5 font-mono text-sm",
                      item.accuracy < 80
                        ? "bg-red-950/40 border-red-900/40 text-red-400"
                        : item.accuracy < 92
                          ? "bg-amber-950/40 border-amber-900/40 text-amber-400"
                          : "bg-surface-tertiary/60 border-surface-border text-slate-400"
                    )}
                  >
                    <span className="font-bold">{item.key}</span>
                    <span className="text-xs">{item.accuracy}%</span>
                    {item.avgLatency > 0 && <span className="text-[10px] text-slate-500">{item.avgLatency}ms</span>}
                  </motion.div>
                ))}
              </div>
            </motion.section>
          )}

          <motion.section
            layout
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ ...bentoTransition, delay: 0.4 }}
            className="relative z-10 rounded-[28px] border border-surface-border bg-surface-secondary/70 p-5 backdrop-blur-xl md:col-span-12"
          >
            <div className="flex flex-col items-center gap-3">
              <div className="flex items-center justify-center gap-3 flex-wrap">
                <button
                  onClick={onRestart}
                  className="flex items-center gap-2 rounded-lg bg-brand px-5 py-2.5 font-mono text-sm font-bold text-surface transition-all hover:bg-brand-dim hover:shadow-[0_12px_28px_rgba(232,245,92,0.18)]"
                >
                  <RotateCcw size={14} />
                  Try again
                  <kbd className="ml-1 rounded bg-surface/20 px-1 py-0.5 text-[10px]">Esc</kbd>
                </button>
                {onDrill && (
                  <button
                    onClick={onDrill}
                    className="flex items-center gap-2 rounded-lg border border-surface-border px-5 py-2.5 font-mono text-sm text-slate-300 transition-all hover:bg-surface-hover hover:-translate-y-0.5"
                  >
                    <Zap size={14} />
                    AI drill for weak keys
                  </button>
                )}
              </div>

              {onNewSession && (
                <button
                  onClick={onNewSession}
                  className="flex items-center gap-2 rounded-lg border border-surface-border px-5 py-2.5 font-mono text-sm text-slate-300 transition-all hover:bg-surface-hover hover:-translate-y-0.5"
                >
                  <Shuffle size={14} />
                  {newSessionLabel}
                  <span className="ml-1 flex items-center gap-1 text-[10px] text-slate-500">
                    <kbd className="rounded bg-surface-tertiary px-1 py-0.5">Tab</kbd>
                    <span>then</span>
                    <kbd className="rounded bg-surface-tertiary px-1 py-0.5">Enter</kbd>
                  </span>
                </button>
              )}
            </div>
          </motion.section>
        </div>
      </div>
    </motion.div>
  );
}
