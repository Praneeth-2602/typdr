"use client";

import Link from "next/link";
import { signOut, useSession } from "next-auth/react";

export function AuthButtons() {
  const { data: session, status } = useSession();

  if (status === "loading") {
    return <span className="font-mono text-xs text-slate-500">Loading…</span>;
  }

  if (!session?.user) {
    return (
      <Link
        href="/signin"
        className="px-4 py-1.5 border border-surface-border text-slate-300 font-mono text-xs rounded-md hover:bg-surface-hover"
      >
        Sign in
      </Link>
    );
  }

  return (
    <div className="flex items-center gap-3">
      <span className="font-mono text-xs text-slate-500">{session.user.name}</span>
      <button
        onClick={() => signOut({ callbackUrl: "/" })}
        className="px-4 py-1.5 border border-surface-border text-slate-300 font-mono text-xs rounded-md hover:bg-surface-hover"
      >
        Sign out
      </button>
    </div>
  );
}
